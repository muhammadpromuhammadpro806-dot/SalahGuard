# 🕌 SalahGuard — Prayer App Blocker

**Real Android app** that blocks distracting apps during prayer time using Android's Accessibility Service.

**Developer:** Hammd Shafiq  
**Package:** `com.muhammadpro.salahguard`

---

## ✨ Features

- 🕌 **Real prayer times** calculated from your GPS location (no API needed)
- 📵 **Real app blocking** via Android Accessibility Service
- 🔔 **Adhan notifications** at each prayer time
- 🎯 **3 Focus Modes:** Soft / Firm / Hard
- 🤲 **Go Pray flow** with Wudu → Qibla → Niyyah steps
- 📿 **Dhikr tracker** (SubhanAllah, Alhamdulillah, etc.)
- 🔥 **Prayer streak** tracking
- 📱 Choose which apps to block (Instagram, YouTube, TikTok, etc.)
- 🔄 **Survives reboots** (alarms auto-reschedule)

---

## 🚀 How to Build & Install (No Android Studio Needed!)

### Step 1 — Create GitHub Repo

1. Go to [github.com](https://github.com) and log in
2. Click **"New repository"** (green button)
3. Name it: `SalahGuard`
4. Set to **Public** (or Private)
5. Click **"Create repository"**

### Step 2 — Upload these files

You have two options:

#### Option A — Upload via GitHub Website (easiest)
1. In your new repo, click **"uploading an existing file"**
2. Drag and drop the entire `SalahGuard` folder
3. Click **"Commit changes"**

#### Option B — Use Git commands
```bash
git clone https://github.com/muhammadpro806-dot/SalahGuard.git
# Copy all these files into the folder
git add .
git commit -m "🕌 Initial SalahGuard commit"
git push
```

### Step 3 — GitHub Actions builds the APK automatically!

1. Go to your repo on GitHub
2. Click the **"Actions"** tab
3. You'll see **"Build SalahGuard APK"** running ⏳
4. Wait 3–5 minutes for it to complete ✅
5. Click on the completed workflow run
6. Scroll down to **"Artifacts"**
7. Download **"SalahGuard-Release-APK"** 📥

### Step 4 — Install on your phone

1. Transfer the APK to your Android phone (email, WhatsApp, USB)
2. On your phone: **Settings → Security → Install unknown apps → Allow**
3. Open the APK file and tap **Install**
4. Open **SalahGuard**

### Step 5 — Enable Accessibility Service (REQUIRED for blocking)

1. The app will prompt you automatically
2. Go to: **Settings → Accessibility → Installed Services → SalahGuard**
3. Toggle it **ON**
4. Confirm the permission
5. ✅ App blocking is now active!

### Step 6 — Configure

1. Open SalahGuard
2. Allow **Location permission** (for accurate prayer times)
3. Go to **Blocker tab** → tap **"Manage Blocked Apps"**
4. Check all apps you want blocked (Instagram, YouTube, TikTok, etc.)
5. Choose your **Focus Mode** (Soft / Firm / Hard)
6. Done! 🎉

---

## 📵 How App Blocking Works

| Mode | What happens when you open a blocked app |
|------|------------------------------------------|
| 🌙 **Soft** | Only notification reminder, no blocking |
| 🔒 **Firm** | Block screen appears, bypass available |
| 🛑 **Hard** | Block screen appears, NO bypass — must pray first |

When prayer time arrives:
1. Adhan notification fires 🔔
2. Accessibility Service activates blocking
3. Any blocked app shows the **SalahGuard block screen**
4. After you pray, tap **"Confirm Prayer Done"** to unlock

---

## 🔧 Troubleshooting

**Prayer times are wrong?**
- Make sure Location permission is granted
- The app uses the Muslim World League calculation method

**Apps not being blocked?**
- Ensure Accessibility Service is enabled (Settings → Accessibility)
- Some Android manufacturers (Xiaomi, Huawei) may require additional battery optimization settings

**Build failed in GitHub Actions?**
- Check the Actions tab for error details
- Make sure all files are uploaded correctly

---

## 📁 Project Structure

```
SalahGuard/
├── .github/workflows/build.yml     ← GitHub Actions (builds APK)
├── app/
│   ├── src/main/
│   │   ├── java/com/muhammadpro/salahguard/
│   │   │   ├── SalahGuardApp.java           ← App class + notifications
│   │   │   ├── service/
│   │   │   │   ├── BlockerAccessibilityService.java  ← REAL app blocker
│   │   │   │   └── AdhanService.java                 ← Adhan + notifications
│   │   │   ├── receiver/
│   │   │   │   ├── PrayerAlarmReceiver.java  ← Prayer time alarms
│   │   │   │   └── BootReceiver.java         ← Restore after reboot
│   │   │   ├── ui/
│   │   │   │   ├── MainActivity.java         ← Main screen
│   │   │   │   ├── BlockActivity.java        ← Block screen
│   │   │   │   ├── GoPrayActivity.java       ← Go pray flow
│   │   │   │   └── AppPickerActivity.java    ← Choose blocked apps
│   │   │   └── utils/
│   │   │       ├── PrayerCalculator.java     ← Prayer time math
│   │   │       ├── PrayerTime.java           ← Prayer model
│   │   │       └── Prefs.java                ← Local storage
│   │   └── res/                    ← Layouts, colors, icons
│   └── build.gradle
├── build.gradle
└── settings.gradle
```

---

## 🤲 May Allah accept your prayers. Ameen.
