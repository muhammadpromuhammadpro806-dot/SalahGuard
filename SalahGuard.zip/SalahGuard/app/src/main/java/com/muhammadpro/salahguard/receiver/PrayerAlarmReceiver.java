package com.muhammadpro.salahguard.receiver;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.muhammadpro.salahguard.service.AdhanService;
import com.muhammadpro.salahguard.utils.PrayerCalculator;
import com.muhammadpro.salahguard.utils.PrayerTime;
import com.muhammadpro.salahguard.utils.Prefs;

import java.util.List;

public class PrayerAlarmReceiver extends BroadcastReceiver {

    public static final String ACTION_PRAYER_TIME = "com.muhammadpro.salahguard.PRAYER_TIME";
    public static final String EXTRA_PRAYER_NAME = "prayer_name";
    public static final String EXTRA_PRAYER_INDEX = "prayer_index";

    @Override
    public void onReceive(Context context, Intent intent) {
        String prayerName = intent.getStringExtra(EXTRA_PRAYER_NAME);
        int prayerIndex = intent.getIntExtra(EXTRA_PRAYER_INDEX, 0);

        // Start Adhan service
        Intent serviceIntent = new Intent(context, AdhanService.class);
        serviceIntent.putExtra(AdhanService.EXTRA_PRAYER_NAME, prayerName);
        serviceIntent.putExtra(AdhanService.EXTRA_PRAYER_INDEX, prayerIndex);
        context.startForegroundService(serviceIntent);

        // Schedule next day's alarm for this prayer
        scheduleNextAlarm(context, prayerIndex);
    }

    public static void scheduleAllAlarms(Context context) {
        Prefs prefs = new Prefs(context);
        if (!prefs.hasLocation()) return;

        PrayerCalculator calc = new PrayerCalculator(prefs.getLat(), prefs.getLng());
        List<PrayerTime> times = calc.getPrayerTimes();

        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        long now = System.currentTimeMillis();

        for (PrayerTime pt : times) {
            long fireTime = pt.timeMillis;
            if (fireTime <= now) continue; // skip past prayers

            Intent intent = new Intent(context, PrayerAlarmReceiver.class);
            intent.setAction(ACTION_PRAYER_TIME);
            intent.putExtra(EXTRA_PRAYER_NAME, pt.name);
            intent.putExtra(EXTRA_PRAYER_INDEX, pt.index);

            PendingIntent pi = PendingIntent.getBroadcast(context,
                1000 + pt.index, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fireTime, pi);
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, fireTime, pi);
            }
        }
    }

    private static void scheduleNextAlarm(Context context, int prayerIndex) {
        // Schedule same prayer for tomorrow
        Prefs prefs = new Prefs(context);
        if (!prefs.hasLocation()) return;

        java.util.Calendar tomorrow = java.util.Calendar.getInstance();
        tomorrow.add(java.util.Calendar.DAY_OF_YEAR, 1);

        PrayerCalculator calc = new PrayerCalculator(prefs.getLat(), prefs.getLng());
        List<PrayerTime> times = calc.getPrayerTimes();

        if (prayerIndex >= times.size()) return;
        PrayerTime pt = times.get(prayerIndex);
        long nextTime = pt.timeMillis + 86400000L; // +1 day

        Intent intent = new Intent(context, PrayerAlarmReceiver.class);
        intent.setAction(ACTION_PRAYER_TIME);
        intent.putExtra(EXTRA_PRAYER_NAME, pt.name);
        intent.putExtra(EXTRA_PRAYER_INDEX, pt.index);

        PendingIntent pi = PendingIntent.getBroadcast(context,
            1000 + pt.index, intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextTime, pi);
        } else {
            am.setExact(AlarmManager.RTC_WAKEUP, nextTime, pi);
        }
    }
}
