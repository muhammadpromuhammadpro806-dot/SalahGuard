package com.muhammadpro.salahguard.ui;

import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.muhammadpro.salahguard.R;
import com.muhammadpro.salahguard.utils.Prefs;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AppPickerActivity extends Activity {

    private Prefs prefs;
    private List<String> appNames = new ArrayList<>();
    private List<String> appPackages = new ArrayList<>();
    private Set<String> blocked;
    private boolean[] checkedItems;
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_picker);

        prefs = new Prefs(this);
        blocked = new HashSet<>(prefs.getBlockedApps());

        loadInstalledApps();

        checkedItems = new boolean[appNames.size()];
        for (int i = 0; i < appPackages.size(); i++) {
            checkedItems[i] = blocked.contains(appPackages.get(i));
        }

        listView = findViewById(R.id.lv_apps);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
            android.R.layout.simple_list_item_multiple_choice, appNames);
        listView.setAdapter(adapter);
        listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);

        for (int i = 0; i < checkedItems.length; i++) {
            listView.setItemChecked(i, checkedItems[i]);
        }

        Button btnSave = findViewById(R.id.btn_save_apps);
        btnSave.setOnClickListener(v -> {
            Set<String> newBlocked = new HashSet<>();
            for (int i = 0; i < appPackages.size(); i++) {
                if (listView.isItemChecked(i)) {
                    newBlocked.add(appPackages.get(i));
                }
            }
            prefs.setBlockedApps(newBlocked);
            Toast.makeText(this, "✅ Blocked apps saved: " + newBlocked.size() + " apps", Toast.LENGTH_SHORT).show();
            finish();
        });

        Button btnBack = findViewById(R.id.btn_back_picker);
        if (btnBack != null) btnBack.setOnClickListener(v -> finish());
    }

    private void loadInstalledApps() {
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);

        // Popular social/entertainment apps to show first
        String[] popularPkgs = {
            "com.instagram.android", "com.google.android.youtube",
            "com.zhiliaoapp.musically", "com.twitter.android",
            "com.facebook.katana", "com.snapchat.android",
            "com.netflix.mediaclient", "com.spotify.music",
            "com.reddit.frontpage", "com.linkedin.android",
            "com.whatsapp", "org.telegram.messenger"
        };

        // Add popular apps first
        for (String pkg : popularPkgs) {
            try {
                ApplicationInfo info = pm.getApplicationInfo(pkg, 0);
                appNames.add(pm.getApplicationLabel(info).toString());
                appPackages.add(pkg);
            } catch (PackageManager.NameNotFoundException ignored) {}
        }

        // Add remaining user apps
        for (ApplicationInfo app : apps) {
            if ((app.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
            if (appPackages.contains(app.packageName)) continue;
            if (app.packageName.startsWith("com.muhammadpro")) continue;
            appNames.add(pm.getApplicationLabel(app).toString());
            appPackages.add(app.packageName);
        }
    }
}
