package com.muhammadpro.salahguard.ui;

import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.muhammadpro.salahguard.R;
import com.muhammadpro.salahguard.utils.Prefs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AppPickerActivity extends Activity {

    private Prefs prefs;
    private final List<String> appNames = new ArrayList<>();
    private final List<String> appPackages = new ArrayList<>();
    private ListView listView;
    private TextView tvLoading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_picker);

        prefs = new Prefs(this);
        listView = findViewById(R.id.lv_apps);
        listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        tvLoading = findViewById(R.id.tv_loading);

        findViewById(R.id.btn_back_picker).setOnClickListener(v -> finish());
        findViewById(R.id.btn_save_apps).setOnClickListener(v -> saveApps());

        loadAppsInBackground();
    }

    private void loadAppsInBackground() {
        if (tvLoading != null) tvLoading.setVisibility(View.VISIBLE);

        ExecutorService executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executor.execute(() -> {
            PackageManager pm = getPackageManager();
            List<ApplicationInfo> installedApps = pm.getInstalledApplications(0);

            List<String> names = new ArrayList<>();
            List<String> packages = new ArrayList<>();

            // Sort alphabetically
            Collections.sort(installedApps, (a, b) ->
                pm.getApplicationLabel(a).toString()
                  .compareToIgnoreCase(pm.getApplicationLabel(b).toString()));

            for (ApplicationInfo app : installedApps) {
                // Skip system apps
                if ((app.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
                // Skip ourselves
                if (app.packageName.equals(getPackageName())) continue;
                String label = pm.getApplicationLabel(app).toString();
                names.add(label);
                packages.add(app.packageName);
            }

            handler.post(() -> {
                appNames.addAll(names);
                appPackages.addAll(packages);

                if (tvLoading != null) tvLoading.setVisibility(View.GONE);

                ArrayAdapter<String> adapter = new ArrayAdapter<>(
                    AppPickerActivity.this,
                    android.R.layout.simple_list_item_multiple_choice,
                    appNames
                );
                listView.setAdapter(adapter);

                // Restore previously blocked apps
                Set<String> blocked = prefs.getBlockedApps();
                for (int i = 0; i < appPackages.size(); i++) {
                    if (blocked.contains(appPackages.get(i))) {
                        listView.setItemChecked(i, true);
                    }
                }

                if (appNames.isEmpty()) {
                    Toast.makeText(AppPickerActivity.this,
                        "No user apps found", Toast.LENGTH_SHORT).show();
                }
            });
        });
    }

    private void saveApps() {
        Set<String> newBlocked = new HashSet<>();
        for (int i = 0; i < appPackages.size(); i++) {
            if (listView.isItemChecked(i)) {
                newBlocked.add(appPackages.get(i));
            }
        }
        prefs.setBlockedApps(newBlocked);
        Toast.makeText(this, "Saved! " + newBlocked.size() + " apps will be blocked",
            Toast.LENGTH_SHORT).show();
        finish();
    }
}
