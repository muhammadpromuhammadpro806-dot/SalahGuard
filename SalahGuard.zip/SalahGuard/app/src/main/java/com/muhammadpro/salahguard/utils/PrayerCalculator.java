package com.muhammadpro.salahguard.utils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

/**
 * Calculates prayer times using the Muslim World League method.
 * Based on standard astronomical algorithms.
 */
public class PrayerCalculator {

    private double latitude;
    private double longitude;
    private double timezone;

    // MWL method angles
    private static final double FAJR_ANGLE = 18.0;
    private static final double ISHA_ANGLE = 17.0;

    public PrayerCalculator(double latitude, double longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
        TimeZone tz = TimeZone.getDefault();
        this.timezone = tz.getOffset(System.currentTimeMillis()) / 3600000.0;
    }

    public List<PrayerTime> getPrayerTimes() {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH) + 1;
        int day = cal.get(Calendar.DAY_OF_MONTH);

        double[] times = calculate(year, month, day);

        List<PrayerTime> list = new ArrayList<>();
        String[] names = {"Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"};
        String[] arabic = {"الفجر", "الظهر", "العصر", "المغرب", "العشاء"};

        for (int i = 0; i < 5; i++) {
            long millis = timeToMillis(times[i], year, month, day);
            list.add(new PrayerTime(i, names[i], arabic[i], millis));
        }
        return list;
    }

    private long timeToMillis(double hours, int year, int month, int day) {
        Calendar cal = Calendar.getInstance();
        cal.set(year, month - 1, day,
            (int) hours,
            (int) ((hours - (int) hours) * 60), 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTimeInMillis();
    }

    private double[] calculate(int year, int month, int day) {
        double jd = julianDate(year, month, day);
        double d = jd - 2451545.0;

        double g = fixAngle(357.529 + 0.98560028 * d);
        double q = fixAngle(280.459 + 0.98564736 * d);
        double l = fixAngle(q + 1.915 * dSin(g) + 0.020 * dSin(2 * g));

        double e = 23.439 - 0.00000036 * d;
        double ra = dArcTan2(dCos(e) * dSin(l), dCos(l)) / 15.0;
        ra = fixHour(ra);

        double eqT = q / 15.0 - ra;
        double decl = dArcSin(dSin(e) * dSin(l));

        double zuhr = 12.0 + timezone - longitude / 15.0 - eqT;
        double sunrise = zuhr - timeDiff(latitude, decl, -0.8333);
        double sunset = zuhr + timeDiff(latitude, decl, -0.8333);
        double fajr = zuhr - timeDiff(latitude, decl, -FAJR_ANGLE);
        double isha = zuhr + timeDiff(latitude, decl, -ISHA_ANGLE);

        // Asr (Shafi method - shadow length factor = 1)
        double asr = zuhr + asrTime(1, latitude, decl);

        return new double[]{fajr, zuhr, asr, sunset, isha};
    }

    private double timeDiff(double lat, double decl, double angle) {
        double num = dSin(angle) - dSin(lat) * dSin(decl);
        double denom = dCos(lat) * dCos(decl);
        return dArcCos(num / denom) / 15.0;
    }

    private double asrTime(int factor, double lat, double decl) {
        double target = dArcCot(factor + dTan(Math.abs(lat - decl)));
        return timeDiff(lat, decl, target);
    }

    private double julianDate(int year, int month, int day) {
        if (month <= 2) { year--; month += 12; }
        double a = Math.floor(year / 100.0);
        double b = 2 - a + Math.floor(a / 4.0);
        return Math.floor(365.25 * (year + 4716)) + Math.floor(30.6001 * (month + 1)) + day + b - 1524.5;
    }

    // Trig helpers
    private double dSin(double d) { return Math.sin(Math.toRadians(d)); }
    private double dCos(double d) { return Math.cos(Math.toRadians(d)); }
    private double dTan(double d) { return Math.tan(Math.toRadians(d)); }
    private double dArcSin(double x) { return Math.toDegrees(Math.asin(x)); }
    private double dArcCos(double x) { return Math.toDegrees(Math.acos(x)); }
    private double dArcTan2(double y, double x) { return Math.toDegrees(Math.atan2(y, x)); }
    private double dArcCot(double x) { return Math.toDegrees(Math.atan(1.0 / x)); }
    private double fixAngle(double a) { return fix(a, 360); }
    private double fixHour(double a) { return fix(a, 24); }
    private double fix(double a, double b) {
        a = a - b * Math.floor(a / b);
        return a < 0 ? a + b : a;
    }
}
