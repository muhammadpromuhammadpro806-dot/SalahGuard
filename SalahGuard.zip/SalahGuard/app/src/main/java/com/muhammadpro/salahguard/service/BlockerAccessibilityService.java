package com.muhammadpro.salahguard.service;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Intent;
import android.view.accessibility.AccessibilityEvent;

import com.muhammadpro.salahguard.ui.BlockActivity;
import com.muhammadpro.salahguard.utils.Prefs;

import java.util.Set;

/**
 * Core service: monitors foreground app and shows BlockActivity
 * when a blocked app is detected during prayer time.
 */
public class BlockerAccessibilityService extends AccessibilityService {

    private Prefs prefs;
    private String lastBlockedPkg = "";

    @Override
    public void onServiceConnected() {
        prefs = new Prefs(this);
        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS;
        info.notificationTimeout = 100;
        setServiceInfo(info);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        if (!prefs.isBlockingActive()) { lastBlockedPkg = ""; return; }

        CharSequence pkgCs = event.getPackageName();
        if (pkgCs == null) return;
        String pkg = pkgCs.toString();

        // Don't block ourselves
        if (pkg.startsWith("com.muhammadpro.salahguard")) return;
        // Don't block system UI
        if (pkg.equals("com.android.systemui") || pkg.equals("android")) return;

        Set<String> blocked = prefs.getBlockedApps();
        int focusMode = prefs.getFocusMode();

        // Mode 1 = soft (no blocking, just notify)
        if (focusMode == 1) return;

        if (blocked.contains(pkg) && !pkg.equals(lastBlockedPkg)) {
            lastBlockedPkg = pkg;
            // Launch block screen
            Intent intent = new Intent(this, BlockActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            intent.putExtra("blocked_pkg", pkg);
            intent.putExtra("focus_mode", focusMode);
            startActivity(intent);
        }
    }

    @Override
    public void onInterrupt() {}

    public static boolean isEnabled(android.content.Context ctx) {
        android.provider.Settings.Secure.getString(
            ctx.getContentResolver(),
            android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        String enabledServices = android.provider.Settings.Secure.getString(
            ctx.getContentResolver(),
            android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        String id = ctx.getPackageName() + "/" + BlockerAccessibilityService.class.getName();
        return enabledServices != null && enabledServices.contains(id);
    }
}
