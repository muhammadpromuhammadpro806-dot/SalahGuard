package com.muhammadpro.salahguard.utils;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

public class Prefs {
    private static final String NAME = "salahguard_prefs";
    private final SharedPreferences sp;

    public Prefs(Context ctx) {
        sp = ctx.getApplicationContext().getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }

    // Location
    public void setLocation(double lat, double lng) {
        sp.edit().putFloat("lat", (float) lat).putFloat("lng", (float) lng).apply();
    }
    public double getLat() { return sp.getFloat("lat", 21.3891f); } // default Makkah
    public double getLng() { return sp.getFloat("lng", 39.8579f); }
    public boolean hasLocation() { return sp.contains("lat"); }

    // Focus mode: 0=off, 1=soft, 2=firm, 3=hard
    public void setFocusMode(int mode) { sp.edit().putInt("focus_mode", mode).apply(); }
    public int getFocusMode() { return sp.getInt("focus_mode", 2); }

    // Blocked apps
    public void setBlockedApps(Set<String> apps) { sp.edit().putStringSet("blocked_apps", apps).apply(); }
    public Set<String> getBlockedApps() {
        return sp.getStringSet("blocked_apps", new HashSet<>());
    }

    // Prayer done flags (reset daily)
    public void setPrayerDone(int index, boolean done) {
        sp.edit().putBoolean("prayer_done_" + index, done).apply();
    }
    public boolean isPrayerDone(int index) { return sp.getBoolean("prayer_done_" + index, false); }
    public void resetDailyPrayers() {
        SharedPreferences.Editor e = sp.edit();
        for (int i = 0; i < 5; i++) e.putBoolean("prayer_done_" + i, false);
        e.apply();
    }

    // Last reset date
    public void setLastResetDate(String date) { sp.edit().putString("last_reset", date).apply(); }
    public String getLastResetDate() { return sp.getString("last_reset", ""); }

    // Streak
    public void setStreak(int streak) { sp.edit().putInt("streak", streak).apply(); }
    public int getStreak() { return sp.getInt("streak", 0); }

    // Adhan enabled per prayer
    public void setAdhanEnabled(int prayerIndex, boolean enabled) {
        sp.edit().putBoolean("adhan_" + prayerIndex, enabled).apply();
    }
    public boolean isAdhanEnabled(int prayerIndex) { return sp.getBoolean("adhan_" + prayerIndex, true); }

    // Blocking active
    public void setBlockingActive(boolean active) { sp.edit().putBoolean("blocking_active", active).apply(); }
    public boolean isBlockingActive() { return sp.getBoolean("blocking_active", false); }

    // Current blocking prayer index
    public void setBlockingPrayerIndex(int idx) { sp.edit().putInt("blocking_prayer_idx", idx).apply(); }
    public int getBlockingPrayerIndex() { return sp.getInt("blocking_prayer_idx", -1); }

    // Dhikr counts
    public void setDhikrCount(int dhikrIndex, int count) {
        sp.edit().putInt("dhikr_" + dhikrIndex, count).apply();
    }
    public int getDhikrCount(int dhikrIndex) { return sp.getInt("dhikr_" + dhikrIndex, 0); }
}
