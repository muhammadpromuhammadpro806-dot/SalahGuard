package com.muhammadpro.salahguard.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.material.tabs.TabLayout;
import com.muhammadpro.salahguard.R;
import com.muhammadpro.salahguard.receiver.PrayerAlarmReceiver;
import com.muhammadpro.salahguard.service.BlockerAccessibilityService;
import com.muhammadpro.salahguard.utils.PrayerCalculator;
import com.muhammadpro.salahguard.utils.PrayerTime;
import com.muhammadpro.salahguard.utils.Prefs;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private Prefs prefs;
    private List<PrayerTime> prayerTimes;
    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable countdownRunnable;

    // Views
    private TextView tvNextPrayer, tvNextTime, tvCountdown, tvDate, tvStreak;
    private View tabHome, tabApps, tabDhikr, tabSettings;
    private View pageHome, pageApps, pageDhikr, pageSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = new Prefs(this);
        initViews();
        checkPermissions();
        loadPrayerTimes();
        startCountdown();
        checkAccessibilityService();
    }

    private void initViews() {
        tvNextPrayer = findViewById(R.id.tv_next_prayer);
        tvNextTime = findViewById(R.id.tv_next_time);
        tvCountdown = findViewById(R.id.tv_countdown);
        tvDate = findViewById(R.id.tv_date);
        tvStreak = findViewById(R.id.tv_streak);

        // Set date
        tvDate.setText(new SimpleDateFormat("EEE, dd MMM yyyy", Locale.getDefault()).format(new Date()));
        tvStreak.setText("🔥 " + prefs.getStreak() + " day streak");

        // Tab switching
        findViewById(R.id.tab_home).setOnClickListener(v -> showPage(0));
        findViewById(R.id.tab_apps).setOnClickListener(v -> showPage(1));
        findViewById(R.id.tab_dhikr).setOnClickListener(v -> showPage(2));
        findViewById(R.id.tab_settings).setOnClickListener(v -> showPage(3));

        pageHome = findViewById(R.id.page_home);
        pageApps = findViewById(R.id.page_apps);
        pageDhikr = findViewById(R.id.page_dhikr);
        pageSettings = findViewById(R.id.page_settings);

        // Go Pray button
        findViewById(R.id.btn_go_pray).setOnClickListener(v -> {
            startActivity(new Intent(this, GoPrayActivity.class));
        });

        // Manage blocked apps button
        findViewById(R.id.btn_manage_apps).setOnClickListener(v -> {
            startActivity(new Intent(this, AppPickerActivity.class));
        });

        // Focus mode buttons
        findViewById(R.id.btn_mode_soft).setOnClickListener(v -> setFocusMode(1, v));
        findViewById(R.id.btn_mode_firm).setOnClickListener(v -> setFocusMode(2, v));
        findViewById(R.id.btn_mode_hard).setOnClickListener(v -> setFocusMode(3, v));
        highlightFocusMode(prefs.getFocusMode());

        // Settings
        findViewById(R.id.btn_accessibility).setOnClickListener(v -> openAccessibilitySettings());
        findViewById(R.id.btn_open_dw).setOnClickListener(v -> openDigitalWellbeing());
    }

    private void showPage(int index) {
        pageHome.setVisibility(index == 0 ? View.VISIBLE : View.GONE);
        pageApps.setVisibility(index == 1 ? View.VISIBLE : View.GONE);
        pageDhikr.setVisibility(index == 2 ? View.VISIBLE : View.GONE);
        pageSettings.setVisibility(index == 3 ? View.VISIBLE : View.GONE);
    }

    private void setFocusMode(int mode, View btn) {
        prefs.setFocusMode(mode);
        highlightFocusMode(mode);
        String[] labels = {"", "🌙 Soft mode on", "🔒 Firm mode on", "🛑 Hard mode on"};
        Toast.makeText(this, labels[mode], Toast.LENGTH_SHORT).show();
    }

    private void highlightFocusMode(int mode) {
        int inactive = 0x33FFFFFF;
        int active = 0xFF00E5A0;
        View soft = findViewById(R.id.btn_mode_soft);
        View firm = findViewById(R.id.btn_mode_firm);
        View hard = findViewById(R.id.btn_mode_hard);
        if (soft == null || firm == null || hard == null) return;
        soft.setAlpha(mode == 1 ? 1f : 0.4f);
        firm.setAlpha(mode == 2 ? 1f : 0.4f);
        hard.setAlpha(mode == 3 ? 1f : 0.4f);
    }

    private void loadPrayerTimes() {
        if (prefs.hasLocation()) {
            calculateAndDisplay();
        } else {
            requestLocation();
        }
    }

    private void calculateAndDisplay() {
        PrayerCalculator calc = new PrayerCalculator(prefs.getLat(), prefs.getLng());
        prayerTimes = calc.getPrayerTimes();
        displayPrayerTimes();
        PrayerAlarmReceiver.scheduleAllAlarms(this);
    }

    private void displayPrayerTimes() {
        if (prayerTimes == null) return;

        long now = System.currentTimeMillis();
        PrayerTime next = null;

        // Update prayer rows
        int[] prayerLayouts = {
            R.id.row_fajr, R.id.row_dhuhr, R.id.row_asr, R.id.row_maghrib, R.id.row_isha
        };
        int[] timeViews = {
            R.id.tv_fajr_time, R.id.tv_dhuhr_time, R.id.tv_asr_time,
            R.id.tv_maghrib_time, R.id.tv_isha_time
        };

        for (int i = 0; i < prayerTimes.size() && i < prayerLayouts.length; i++) {
            PrayerTime pt = prayerTimes.get(i);
            TextView tv = findViewById(timeViews[i]);
            if (tv != null) tv.setText(pt.getFormattedTime());
            if (pt.timeMillis > now && next == null) next = pt;
        }

        if (next != null) {
            tvNextPrayer.setText(next.name);
            tvNextTime.setText(next.getFormattedTime());
        }
    }

    private void startCountdown() {
        countdownRunnable = new Runnable() {
            @Override
            public void run() {
                updateCountdown();
                handler.postDelayed(this, 1000);
            }
        };
        handler.post(countdownRunnable);
    }

    private void updateCountdown() {
        if (prayerTimes == null) return;
        long now = System.currentTimeMillis();
        PrayerTime next = null;
        for (PrayerTime pt : prayerTimes) {
            if (pt.timeMillis > now) { next = pt; break; }
        }
        if (next == null) { tvCountdown.setText("--:--:--"); return; }

        long diff = next.timeMillis - now;
        long h = diff / 3600000;
        long m = (diff % 3600000) / 60000;
        long s = (diff % 60000) / 1000;
        tvCountdown.setText(String.format(Locale.getDefault(), "%02d:%02d:%02d", h, m, s));
    }

    private void checkAccessibilityService() {
        if (!BlockerAccessibilityService.isEnabled(this)) {
            new AlertDialog.Builder(this)
                .setTitle("⚙️ Enable Accessibility Service")
                .setMessage("SalahGuard needs Accessibility permission to block apps during prayer time.\n\nTap OK → find SalahGuard → enable it.")
                .setPositiveButton("Open Settings", (d, w) -> openAccessibilitySettings())
                .setNegativeButton("Later", null)
                .show();
        }
    }

    private void openAccessibilitySettings() {
        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
    }

    private void openDigitalWellbeing() {
        try {
            startActivity(new Intent("android.settings.ACTION_DIGITAL_WELLBEING_SETTINGS"));
        } catch (Exception e) {
            Toast.makeText(this, "Open Settings → Digital Wellbeing manually", Toast.LENGTH_LONG).show();
        }
    }

    private void checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
            }
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 2);
        }
    }

    private void requestLocation() {
        FusedLocationProviderClient client = LocationServices.getFusedLocationProviderClient(this);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            == PackageManager.PERMISSION_GRANTED) {
            client.getLastLocation().addOnSuccessListener(location -> {
                if (location != null) {
                    prefs.setLocation(location.getLatitude(), location.getLongitude());
                    calculateAndDisplay();
                } else {
                    // Default to Makkah if no location
                    prefs.setLocation(21.3891, 39.8579);
                    calculateAndDisplay();
                    Toast.makeText(this, "Using default location (Makkah). Update in settings.", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, @NonNull String[] perms, @NonNull int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        if (req == 2 && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            requestLocation();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(countdownRunnable);
    }
}
