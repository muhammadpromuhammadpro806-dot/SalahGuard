package com.muhammadpro.salahguard.service;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import com.muhammadpro.salahguard.R;
import com.muhammadpro.salahguard.SalahGuardApp;
import com.muhammadpro.salahguard.ui.MainActivity;
import com.muhammadpro.salahguard.utils.Prefs;

public class AdhanService extends Service {

    public static final String EXTRA_PRAYER_NAME = "prayer_name";
    public static final String EXTRA_PRAYER_INDEX = "prayer_index";

    private MediaPlayer mediaPlayer;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }

        String prayerName = intent.getStringExtra(EXTRA_PRAYER_NAME);
        int prayerIndex = intent.getIntExtra(EXTRA_PRAYER_INDEX, 0);

        // Start blocking
        Prefs prefs = new Prefs(this);
        int focusMode = prefs.getFocusMode();
        if (focusMode >= 2) {
            prefs.setBlockingActive(true);
            prefs.setBlockingPrayerIndex(prayerIndex);
        }

        // Show foreground notification
        startForeground(100 + prayerIndex, buildNotification(prayerName));

        // Play adhan sound (using default notification sound as fallback)
        playAdhan(prefs.isAdhanEnabled(prayerIndex));

        // Vibrate
        vibrate();

        // Auto-stop after 3 minutes
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(this::stopSelf, 180000);

        return START_NOT_STICKY;
    }

    private void playAdhan(boolean enabled) {
        if (!enabled) return;
        try {
            Uri sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build());
            mediaPlayer.setDataSource(this, sound);
            mediaPlayer.setLooping(false);
            mediaPlayer.prepare();
            mediaPlayer.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void vibrate() {
        Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (v == null) return;
        long[] pattern = {0, 500, 300, 500, 300, 1000};
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createWaveform(pattern, -1));
        } else {
            v.vibrate(pattern, -1);
        }
    }

    private Notification buildNotification(String prayerName) {
        Intent mainIntent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, mainIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, SalahGuardApp.CHANNEL_ADHAN)
            .setSmallIcon(R.drawable.ic_mosque)
            .setContentTitle("🕌 " + prayerName + " Prayer Time")
            .setContentText("حَيَّ عَلَى الصَّلَاةِ — Come to prayer")
            .setStyle(new NotificationCompat.BigTextStyle()
                .bigText("It is time for " + prayerName + " prayer.\nApp blocking is now active."))
            .setContentIntent(pi)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(false)
            .setOngoing(true)
            .build();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
        }
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
