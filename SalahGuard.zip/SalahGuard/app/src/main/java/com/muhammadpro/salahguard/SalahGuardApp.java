package com.muhammadpro.salahguard;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;

public class SalahGuardApp extends Application {

    public static final String CHANNEL_ADHAN = "salahguard_adhan";
    public static final String CHANNEL_BLOCKER = "salahguard_blocker";
    public static final String CHANNEL_GENERAL = "salahguard_general";

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannels();
    }

    private void createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);

            // Adhan channel - high importance for sound
            NotificationChannel adhan = new NotificationChannel(
                CHANNEL_ADHAN, "Adhan & Prayer Times",
                NotificationManager.IMPORTANCE_HIGH
            );
            adhan.setDescription("Adhan call and prayer time alerts");
            adhan.enableVibration(true);
            adhan.setShowBadge(true);
            nm.createNotificationChannel(adhan);

            // Blocker channel
            NotificationChannel blocker = new NotificationChannel(
                CHANNEL_BLOCKER, "App Blocker",
                NotificationManager.IMPORTANCE_LOW
            );
            blocker.setDescription("Active during prayer app blocking");
            nm.createNotificationChannel(blocker);

            // General channel
            NotificationChannel general = new NotificationChannel(
                CHANNEL_GENERAL, "General",
                NotificationManager.IMPORTANCE_DEFAULT
            );
            nm.createNotificationChannel(general);
        }
    }
}
