package com.muhammadpro.salahguard.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.muhammadpro.salahguard.R;
import com.muhammadpro.salahguard.utils.Prefs;

public class BlockActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Show over lock screen
        getWindow().addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        );

        setContentView(R.layout.activity_block);

        Prefs prefs = new Prefs(this);
        int focusMode = getIntent().getIntExtra("focus_mode", 2);

        TextView tvMode = findViewById(R.id.tv_focus_mode);
        Button btnBypass = findViewById(R.id.btn_bypass);
        Button btnGoPray = findViewById(R.id.btn_go_pray);

        if (focusMode == 3) {
            // Hard mode - no bypass
            btnBypass.setVisibility(View.GONE);
            tvMode.setText("🛑 Hard Mode — No bypass allowed");
        } else {
            // Firm mode - bypass available
            tvMode.setText("🔒 Firm Mode — You can bypass");
            btnBypass.setVisibility(View.VISIBLE);
            btnBypass.setOnClickListener(v -> {
                prefs.setBlockingActive(false);
                finish();
            });
        }

        btnGoPray.setOnClickListener(v -> {
            startActivity(new Intent(this, GoPrayActivity.class));
            finish();
        });

        // Back press does nothing (trap the user)
    }

    @Override
    public void onBackPressed() {
        // Intentionally blocked
    }
}
