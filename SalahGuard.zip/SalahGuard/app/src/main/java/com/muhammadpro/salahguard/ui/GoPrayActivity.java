package com.muhammadpro.salahguard.ui;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import com.muhammadpro.salahguard.R;
import com.muhammadpro.salahguard.utils.Prefs;

public class GoPrayActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_go_pray);

        Prefs prefs = new Prefs(this);

        Button btnConfirm = findViewById(R.id.btn_confirm_prayer);
        btnConfirm.setOnClickListener(v -> {
            // Mark prayer as done, stop blocking
            int idx = prefs.getBlockingPrayerIndex();
            if (idx >= 0) prefs.setPrayerDone(idx, true);
            prefs.setBlockingActive(false);
            Toast.makeText(this, "🤲 Alhamdulillah! Prayer confirmed.", Toast.LENGTH_LONG).show();
            finish();
        });

        Button btnBack = findViewById(R.id.btn_back);
        if (btnBack != null) btnBack.setOnClickListener(v -> finish());
    }
}
