package com.muhammadpro.salahguard.utils;

public class PrayerTime {
    public String name;
    public String arabicName;
    public long timeMillis;
    public boolean done;
    public boolean adhanEnabled;
    public int index;

    public PrayerTime(int index, String name, String arabicName, long timeMillis) {
        this.index = index;
        this.name = name;
        this.arabicName = arabicName;
        this.timeMillis = timeMillis;
        this.done = false;
        this.adhanEnabled = true;
    }

    public String getFormattedTime() {
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.setTimeInMillis(timeMillis);
        int hour = cal.get(java.util.Calendar.HOUR_OF_DAY);
        int min = cal.get(java.util.Calendar.MINUTE);
        String ampm = hour >= 12 ? "PM" : "AM";
        int h = hour % 12;
        if (h == 0) h = 12;
        return String.format(java.util.Locale.getDefault(), "%d:%02d %s", h, min, ampm);
    }
}
